//Desafio

var valorVenda = prompt("Informe o valor de Venda");
valorVenda = parseFloat(valorVenda);

pergunta = prompt ("Informe o pagamento: 1 Avista, 2 À Prazo 30 dias, 3 À Prazo 60 dias, 4 À Prazo 90 dias, 5 Débito, 6 Crédito: ");
pergunta = parseInt(pergunta);

switch(pergunta){

    case 1 :
        
        document.write("Com desconto de 10% o valor ficará R$ " +(valorVenda*0.9));
        break
    
    case 2 :
        document.write("Pagamento a prazp de 30 dias +5% de desconto " +(valorVenda*0.95));
        break

    case 3 :
        document.write("Pagamento a prazo de 60 dias, o valor é " +valorVenda );
        break

    case 4 :
        document.write("A prazo de 90 dias - 5% de acréscimo " + (valorVenda*1.05));
        break

    case 5 :
        document.write("Débito com 8% de desconto " + (valorVenda*0.92));
        break

    case 6 :
        document.write("Crédito com 7% de desconto " +(valorVenda*0.93));
        break;   
    default:
        document.write("Caso Inválido");
}dasdas
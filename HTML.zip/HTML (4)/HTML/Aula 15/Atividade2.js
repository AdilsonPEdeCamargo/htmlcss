//Exercicio Slide

var pergunta = prompt("DIGA UMA LETRA SEU JUDEU");
var vogal = "a";
var vogal1 = "e";
var vogal2 = "i";
var vogal3 = "o";
var vogal4 = "u";

if(pergunta == vogal){
    document.write("A letra é uma vogal ");
} else if(pergunta == vogal1){
    document.write("A letra é uma vogal ");
}  else if(pergunta == vogal2){
    document.write("A letra é uma vogal ");
}  else if(pergunta == vogal3){
    document.write("A letra é uma vogal ");
}  else if(pergunta == vogal4){
    document.write("A letra é uma vogal ");
}  else{
    document.write("A letra é uma consoante");
}
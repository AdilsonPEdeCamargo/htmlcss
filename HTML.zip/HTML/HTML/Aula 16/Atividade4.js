//ATIVIDADE 4 SLIDES AULA 16

for (var i = 5; i<=30; i++){
    if(i  % 2 != 0){
        document.write(i +"<br>");
    }   
}
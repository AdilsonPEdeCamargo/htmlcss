
var i = 90

var i = parseInt(i);


for(i; i<= 200; i++){
    document.write(i);
}
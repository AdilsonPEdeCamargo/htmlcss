//estrutura for

var i = 0;

for(i; i<=10; i++){

    if(i %2 == 0){
        document.write("PARES" + i);
    }else{
        document.write("ÍMPARES" +i)
    }

}
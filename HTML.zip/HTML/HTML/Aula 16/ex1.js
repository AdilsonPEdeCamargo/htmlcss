//estrutura for

var i = prompt("Digite um valor entre 0 e 2");
var pergunta = parseInt(pergunta);


for(pergunta; pergunta<= 10; pergunta++){
    document.write(pergunta);
}
//ATIVIDADE 5 SLIDES AULA 16

var numero = 5;


for (var i = 1; i <= 10; i++) {
  var resultado = numero * i;
  document.write(numero + " x " + i + " = " + resultado + "<br>");
}
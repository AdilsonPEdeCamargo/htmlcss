//Funções do JS Array ou Matriz
var arraya = ['Senac', 10, 20, 20, undefined];
var arrayb = ['Caxias', 30, 40, 50, null];

arraya = arraya.concat(arrayb);

document.write(arraya);
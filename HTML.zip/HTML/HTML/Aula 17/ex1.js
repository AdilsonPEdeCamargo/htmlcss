//Vetores JS e funções de Vetores
var array = ['a','b','c','d'];

//Imprimir um vetor
for(var i = 0; i< array.length; i++){
    document.write(i);
    document.write(array[i]);
    document.write(array[2]);
}
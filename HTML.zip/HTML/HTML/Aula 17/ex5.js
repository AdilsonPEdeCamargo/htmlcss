//Funções do JS Array ou Matriz
var arraya = ['Senac', 10, 20, 20];
arraya.pop();

console.log(arraya)
document.write(arraya);
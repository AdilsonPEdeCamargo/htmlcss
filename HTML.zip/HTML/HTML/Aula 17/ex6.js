//Funções do JS Array ou Matriz
var arraya = ['Senac', 10, 20, 20];
var novoArray = arraya.slice(1,3);

console.log(novoArray)
document.write(novoArray);
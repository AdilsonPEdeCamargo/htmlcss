//Atividade 3

var vetor = new Array(4);

var multi = 1;
var soma = 0;
var resultado = 0;

for(var i = 0; i < vetor.length; i++){
    vetor[i] = new Array(prompt("Digite os valores:"));
    vetor[i]= parseInt(vetor[i]);

    multi = (vetor[0]*vetor[2]); 
    soma = (vetor[1]+vetor[3]);
    resultado = (multi/soma)
    
    //document.write(vetor[i]);
    
}
document.write("<br>"+resultado);
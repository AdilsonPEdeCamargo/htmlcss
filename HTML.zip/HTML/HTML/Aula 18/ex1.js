function imprimirAtributos(){
        
    var nome = document.getElementById('nome').value;
    var telefone = document.getElementById('telefone').value;
    var email = document.getElementById('email').valeu;

    document.write(nome + '' + telefone + ' ' + email);
    }
function imprimirAtributos(){

    var nome = document.getElementById('nome').value.trim();
    var telefone = document.getElementById('telefone').value.trim();
    var email = document.getElementById('email').value.trim();

    if(nome === ''){
        alert('Campo Nome em Branco');
    }else if(telefone === ''){
        alert('Campo Telefone em Branco');
    }else if(email === ''){
        alert('Campo Email em Branco');
    }else{
        document.write(nome + ' ' + telefone + ' ' + email);
    }
}
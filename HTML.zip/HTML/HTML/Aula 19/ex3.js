function imprimirAtributos(){

    var nome = document.getElementById('nome').value.trim();
    var cpf = document.getElementById('cpf').value.trim();
    var endereco = document.getElementById('endereco').value.trim();
    var email = document.getElementById('email').value.trim();
    var senha = document.getElementById('senha').value.trim();
    var nivel = document.getElementById('nivel').value.trim();
    var status = document.getElementById('status').value.trim();

        if(nome === ''){
            alert("Campo Nome em Branco")
        }else if(cpf === ''){
            alert('Campo CPF em Branco')
        }else if(endereco === ''){
            alert('Campo Endereço em Branco')
        }else if(email === ''){
            alert('Campo Email em Branco')
        }else if(senha === ''){
            alert('Campo Senha em Branco')
        }else{
            document.write("Nome: "+nome+"<br>"+"CPF: "+cpf+"<br>"+"Endereço: "+endereco+ "<br>"+"Email: "+email +"<br>"+"Nível: "+ nivel+ "<br>"+"Status: "+ status );
        }

}
function limparCampos(){
    nome = ' ';
    cpf = ' ';
    endereco = ' ';
    email = ' ';
    senha = ' ';
    nivel = ' ';
}
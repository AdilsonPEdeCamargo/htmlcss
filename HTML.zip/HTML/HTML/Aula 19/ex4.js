function imprimirAtributos(){

    var nome = document.getElementById('nome').value.trim();
    var email = document.getElementById('email').value.trim();
    var data = document.getElementById('data').value.trim();
    var exampleRadios = document.querySelector('input[name="exampleRadios"]:checked');
    
    var recebe = [];
    var checks = document.querySelectorAll('.check:checked');

        if(nome === ''){
            alert("Campo Nick em Branco")
        }else if(email === ''){
            alert('Campo Email em Branco')
        }else if(data === ''){
            alert('Campo Nascença em Branco')
        }else if(!exampleRadios){
            alert('Selecione pelo menos 1 campo IMBECIL')
        }else if(checks.length < 1 || checks.length > 2){
            alert('Selecione pelo menos 1 opção IMBECIL')
        }else{
            
            for(var i = 0; i < checks.length; i++){
                recebe.push(checks[i].value);
            }
        
            document.write("Nick: "+nome+"<br>"+"Email: "+email+"<br>"+"Nascença: "+data + "CheckBOX: " + exampleRadios.value + recebe.join(' - '));
        
        }
}
function limparCampos(){
    nome = ' ';
    email = ' ';
    data = ' ';

}
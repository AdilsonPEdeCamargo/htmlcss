var nome = "VAI CURINTIA";
var cpf = "82.32.222";
var n1 = 10.4;
var telefone = prompt("Digite seu Nome");
var n2 = prompt(";Digite um Número");
n2 = parseInt(n2)
var n3 = prompt("Digite um Número");
n3 = parseInt(n3);

var resultado = (n2+n3);

//COMANDO DE SAÍDA JS
//alert(nome + cpf);

//COMANDO DE SAÍDA DO JS p/HTML
document.write(nome + "<br>" + cpf + "<br>" + n1 + "<br>" + telefone + "<br>" + n2 + "<br>" + n3);
document.write(resultado);

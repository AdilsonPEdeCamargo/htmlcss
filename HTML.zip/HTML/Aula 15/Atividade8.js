//Atividade 8 slides aula 15

var n1 = prompt("Informe um valor");
n1 = parseFloat(n1);

var n2 = prompt("Informe um valor");
n2 = parseFloat(n2);

var n3 = prompt("Informe um valor");
n3 = parseFloat(n3);

var resultado; 
resultado = (n1*n2*n3);

document.write("O resultado da multiplicação é: " +resultado);